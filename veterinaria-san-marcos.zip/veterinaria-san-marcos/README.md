# Veterinaria San Marcos - Tienda Online (Frontend)

Proyecto para la **Evaluación Parcial 1** de DSY1104 - Desarrollo FullStack II.
Caso asignado: **Forma A - Veterinaria San Marcos**.

Sitio web construido con **HTML5, CSS3 y JavaScript puro (sin frameworks)**,
tal como lo exige esta primera entrega (el stack React + Spring Boot descrito
en el documento de contexto corresponde a evaluaciones posteriores del semestre).

## Estructura del proyecto

```
veterinaria-san-marcos/
├── index.html               # Home de la tienda
├── productos.html           # Listado de productos con filtro por categoría
├── detalle-producto.html    # Detalle de un producto + relacionados
├── carrito.html             # Carrito de compras (localStorage)
├── registro.html            # Registro de usuario (con validaciones JS)
├── login.html                # Inicio de sesión (con validaciones JS)
├── nosotros.html             # Historia de la clínica + video embebido
├── blogs.html                 # Listado de noticias/casos curiosos
├── detalle-blog1.html         # Detalle blog 1
├── detalle-blog2.html         # Detalle blog 2
├── contacto.html               # Formulario de contacto + mapa embebido
├── admin/
│   ├── index.html              # Home del panel administrador
│   ├── usuarios.html           # Listado de usuarios
│   ├── usuario-nuevo.html      # Crear / editar usuario (?index=N)
│   ├── productos.html          # Listado de productos (admin)
│   └── producto-nuevo.html     # Crear / editar producto (?index=N)
├── css/
│   ├── styles.css              # Estilos generales del sitio
│   └── admin.css               # Estilos del panel administrador
└── js/
    ├── productos.js             # Catálogo de productos y render de vistas
    ├── carrito.js                # Lógica del carrito (localStorage)
    ├── validaciones.js           # Validaciones de formularios (login, registro, contacto)
    ├── regiones.js                # Dataset de regiones/comunas para selects dependientes
    ├── admin.js                   # Mantenedores de usuarios y productos (admin)
    └── main.js                     # Menú móvil, año dinámico, newsletter
```

## Cómo abrir el proyecto en VS Code

1. Descomprime la carpeta `veterinaria-san-marcos`.
2. Ábrela en VS Code (`Archivo > Abrir carpeta...`).
3. Instala la extensión **Live Server** (si no la tienes) y haz clic derecho
   sobre `index.html` → **Open with Live Server**. También puedes abrir el
   archivo directamente con doble clic desde el explorador de archivos.

## Requisitos cubiertos (según Anexo 1 y rúbrica)

- **Estructura HTML5 semántica:** `<header>`, `<nav>`, `<main>`, `<section>`,
  `<article>` y `<footer>` en todas las vistas.
- **Navegación:** menú superior con hipervínculos entre todas las páginas,
  breadcrumbs en detalle de producto y blogs.
- **Elementos interactivos:** imágenes, botones, video embebido (YouTube) en
  Nosotros, mapa embebido (OpenStreetMap) en Contacto, formularios en
  Registro, Login, Contacto y en el panel administrador.
- **CSS externo y consistente:** una sola hoja de estilos (`styles.css`) más
  una hoja específica para el panel administrador (`admin.css`), ambas
  enlazadas de forma externa en cada página.
- **Validaciones JavaScript:**
  - Login y Registro: correo (solo `@duoc.cl`, `@profesor.duoc.cl`,
    `@gmail.com`), contraseña (4 a 10 caracteres), confirmación de
    contraseña, validación de RUN chileno con dígito verificador.
  - Contacto: nombre, correo y comentario con largo máximo.
  - Panel administrador (usuario y producto): validaciones específicas de
    cada campo (rangos numéricos, campos requeridos/opcionales, selects
    dependientes de región/comuna).
  - Mensajes de error personalizados y contextuales bajo cada campo.
- **Carrito de compras:** se guarda en `localStorage`, permite sumar/restar
  cantidades y se refleja en el contador del header en todas las páginas.
- **Panel administrador:** mantenedor de productos y usuarios (listar, crear,
  editar, eliminar) simulado en el frontend con `localStorage`, ya que en
  esta entrega solo se solicita el proyecto frontend (sin backend).

## Pendiente para completar la entrega del encargo

1. **Repositorio GitHub:** crear un repositorio público, subir este proyecto
   y hacer commits descriptivos y distribuidos entre los integrantes del
   equipo (requisito IE1.3.1 de la rúbrica).
2. **Documento ERS (versión 1 - propuesta previa):** completar el anexo ERS
   con la información de Veterinaria San Marcos (introducción, alcance,
   usuarios, requisitos funcionales/no funcionales). Puedo ayudarte a
   redactar ese documento en un archivo Word aparte si lo necesitas.
3. **Personalizar imágenes:** reemplaza los bloques `placeholder-img` por
   fotografías reales cuando el equipo las tenga disponibles.
4. **Ajustar datos del equipo:** en `nosotros.html` puedes agregar nombres
   reales de los integrantes si el docente lo requiere.

## Nota sobre el contexto de negocio

El documento "Forma A" describe el proyecto completo del semestre (con
React, Spring Boot, microservicios y roles RBAC). Para esta Evaluación
Parcial 1 solo se construye la base de la tienda en HTML/CSS/JS puro, usando
el catálogo de servicios y productos veterinarios como contenido de la
tienda (vacunas, antiparasitarios, medicamentos y servicios), en lugar de
los datos genéricos ("Product Title") de los mockups.
