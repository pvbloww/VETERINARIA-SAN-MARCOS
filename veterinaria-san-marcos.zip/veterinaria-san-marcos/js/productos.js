/* =========================================================
   Veterinaria San Marcos - Catálogo de productos
   Datos basados en Anexo "Catálogo Veterinaria San Marcos"
   ========================================================= */

const CATALOGO_PRODUCTOS = [
  {
    id: "VA001",
    nombre: "Vacuna antirrábica canina",
    categoria: "Vacunas",
    precio: 12000,
    stock: 48,
    stockCritico: 10,
    descripcion:
      "Vacuna antirrábica obligatoria por ley para perros. Protege contra la rabia y debe aplicarse anualmente. Duración aproximada de la atención: 10 minutos.",
  },
  {
    id: "VA003",
    nombre: "Vacuna bivalente felina",
    categoria: "Vacunas",
    precio: 15000,
    stock: 36,
    stockCritico: 8,
    descripcion:
      "Refuerzo anual para gatos que protege contra las principales enfermedades virales felinas. Duración aproximada de la atención: 10 minutos.",
  },
  {
    id: "VA005",
    nombre: "Vacuna Bordetella canina",
    categoria: "Vacunas",
    precio: 14000,
    stock: 22,
    stockCritico: 5,
    descripcion:
      "Conocida como la vacuna contra la 'tos de las perreras'. Recomendada para perros que asisten a guarderías o residencias caninas.",
  },
  {
    id: "DE001",
    nombre: "Desparasitación interna pequeños (<10 kg)",
    categoria: "Desparasitación",
    precio: 8000,
    stock: 60,
    stockCritico: 15,
    descripcion:
      "Tratamiento antiparasitario interno para perros de hasta 10 kg. Atención rápida, aproximadamente 5 minutos.",
  },
  {
    id: "DE005",
    nombre: "Antiparasitario externo (pipeta)",
    categoria: "Desparasitación",
    precio: 7500,
    stock: 40,
    stockCritico: 10,
    descripcion:
      "Pipeta antiparasitaria externa para perros y gatos. Incluye aplicación por personal veterinario.",
  },
  {
    id: "ME004",
    nombre: "Nexgard (Afoxolaner)",
    categoria: "Antiparasitarios",
    precio: 9500,
    stock: 60,
    stockCritico: 12,
    descripcion:
      "Comprimido masticable antiparasitario para perros. Presentación de 1 unidad, protege contra pulgas y garrapatas.",
  },
  {
    id: "ME006",
    nombre: "Revolution Plus",
    categoria: "Antiparasitarios",
    precio: 14500,
    stock: 35,
    stockCritico: 8,
    descripcion:
      "Pipeta antiparasitaria de amplio espectro para gatos. Combina selamectina y sarolaner en una sola aplicación.",
  },
  {
    id: "ME009",
    nombre: "Meloxicam 1mg",
    categoria: "Medicamentos",
    precio: 4500,
    stock: 55,
    stockCritico: 10,
    descripcion:
      "Antiinflamatorio de uso veterinario para perros y gatos. Blíster de 10 comprimidos, requiere indicación médica.",
  },
  {
    id: "ME011",
    nombre: "Clorhexidina shampoo",
    categoria: "Dermatología",
    precio: 8900,
    stock: 25,
    stockCritico: 5,
    descripcion:
      "Shampoo dermatológico con clorhexidina al 2%, indicado para el cuidado de la piel de perros y gatos. Frasco de 250 ml.",
  },
  {
    id: "ME021",
    nombre: "Omega vet 3-6-9",
    categoria: "Suplementos",
    precio: 9900,
    stock: 30,
    stockCritico: 6,
    descripcion:
      "Suplemento con ácidos grasos omega para mantener un pelaje saludable y brillante. Frasco de 100 ml.",
  },
  {
    id: "OT001",
    nombre: "Corte de uñas",
    categoria: "Servicios",
    precio: 5000,
    stock: 99,
    stockCritico: 0,
    descripcion:
      "Servicio de corte de uñas para perros y gatos, realizado por personal capacitado. Duración aproximada de 15 minutos.",
  },
  {
    id: "OT003",
    nombre: "Microchip identificación",
    categoria: "Servicios",
    precio: 15000,
    stock: 99,
    stockCritico: 0,
    descripcion:
      "Implante de microchip de identificación, incluye registro. Ayuda a reencontrar a tu mascota en caso de pérdida.",
  },
];

const CATEGORIAS_PRODUCTOS = [
  "Todos",
  ...Array.from(new Set(CATALOGO_PRODUCTOS.map((p) => p.categoria))),
];

function formatearCLP(valor) {
  return valor.toLocaleString("es-CL", {
    style: "currency",
    currency: "CLP",
    maximumFractionDigits: 0,
  });
}

function obtenerProductoPorId(id) {
  return CATALOGO_PRODUCTOS.find((p) => p.id === id);
}

/* ---- Renderizado de la grilla de productos (productos.html) ---- */
function renderizarGridProductos(categoriaSeleccionada = "Todos") {
  const contenedor = document.getElementById("grid-productos");
  if (!contenedor) return;

  const lista =
    categoriaSeleccionada === "Todos"
      ? CATALOGO_PRODUCTOS
      : CATALOGO_PRODUCTOS.filter((p) => p.categoria === categoriaSeleccionada);

  contenedor.innerHTML = lista
    .map(
      (p) => `
      <div class="tarjeta-producto">
        <a href="detalle-producto.html?id=${p.id}">
          <div class="placeholder-img">${p.nombre}</div>
        </a>
        <div class="info">
          <span class="categoria">${p.categoria}</span>
          <h3><a href="detalle-producto.html?id=${p.id}">${p.nombre}</a></h3>
          <span class="precio">${formatearCLP(p.precio)}</span>
          <button class="btn btn-primario btn-bloque" type="button" onclick="agregarAlCarrito('${p.id}', 1)">
            Añadir al carrito
          </button>
        </div>
      </div>`
    )
    .join("");
}

function renderizarFiltros() {
  const contenedor = document.getElementById("filtros-categoria");
  if (!contenedor) return;

  contenedor.innerHTML = CATEGORIAS_PRODUCTOS.map(
    (cat, i) =>
      `<button type="button" class="${i === 0 ? "activo" : ""}" data-categoria="${cat}">${cat}</button>`
  ).join("");

  contenedor.querySelectorAll("button").forEach((btn) => {
    btn.addEventListener("click", () => {
      contenedor
        .querySelectorAll("button")
        .forEach((b) => b.classList.remove("activo"));
      btn.classList.add("activo");
      renderizarGridProductos(btn.dataset.categoria);
    });
  });
}

/* ---- Renderizado del detalle de producto (detalle-producto.html) ---- */
function renderizarDetalleProducto() {
  const contenedorDetalle = document.getElementById("detalle-producto");
  if (!contenedorDetalle) return;

  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  const producto = obtenerProductoPorId(id) || CATALOGO_PRODUCTOS[0];

  document.title = `${producto.nombre} - Veterinaria San Marcos`;
  document.getElementById("miga-producto").textContent = producto.nombre;

  contenedorDetalle.innerHTML = `
    <div>
      <div class="placeholder-img" style="aspect-ratio:1/1;">${producto.nombre}</div>
    </div>
    <div>
      <span class="categoria">${producto.categoria}</span>
      <h1>${producto.nombre}</h1>
      <p class="precio-grande">${formatearCLP(producto.precio)}</p>
      <p>${producto.descripcion}</p>
      <p><strong>Stock disponible:</strong> ${producto.stock} unidades</p>
      <form id="form-agregar-carrito">
        <div class="selector-cantidad">
          <label for="cantidad">Cantidad</label>
          <input type="number" id="cantidad" name="cantidad" min="1" max="${producto.stock}" value="1" />
        </div>
        <button class="btn btn-primario" type="submit">Añadir al carrito</button>
      </form>
      <p id="mensaje-agregado" class="alerta alerta-exito" style="display:none;">
        Producto añadido al carrito.
      </p>
    </div>
  `;

  document
    .getElementById("form-agregar-carrito")
    .addEventListener("submit", (evento) => {
      evento.preventDefault();
      const cantidad = parseInt(document.getElementById("cantidad").value, 10) || 1;
      agregarAlCarrito(producto.id, cantidad);
      const mensaje = document.getElementById("mensaje-agregado");
      mensaje.style.display = "block";
      setTimeout(() => (mensaje.style.display = "none"), 2500);
    });

  renderizarRelacionados(producto);
}

function renderizarRelacionados(productoActual) {
  const contenedor = document.getElementById("productos-relacionados");
  if (!contenedor) return;
  const relacionados = CATALOGO_PRODUCTOS.filter(
    (p) => p.categoria === productoActual.categoria && p.id !== productoActual.id
  ).slice(0, 4);

  contenedor.innerHTML = relacionados
    .map(
      (p) => `
      <a href="detalle-producto.html?id=${p.id}" class="tarjeta-producto">
        <div class="placeholder-img">${p.nombre}</div>
        <div class="info">
          <h3>${p.nombre}</h3>
          <span class="precio">${formatearCLP(p.precio)}</span>
        </div>
      </a>`
    )
    .join("");
}

document.addEventListener("DOMContentLoaded", () => {
  renderizarFiltros();
  renderizarGridProductos();
  renderizarDetalleProducto();
});
