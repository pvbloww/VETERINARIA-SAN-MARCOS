/* =========================================================
   Veterinaria San Marcos - Validaciones de formularios
   Reglas basadas en el Anexo 1 - Instrucciones de la
   Evaluación Parcial 1.
   ========================================================= */

const REGEX_CORREO_PERMITIDO = /^[^\s@]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/i;

/** Muestra un mensaje de error bajo un campo y marca el estado visual. */
function marcarCampo(inputEl, mensaje) {
  const campo = inputEl.closest(".campo");
  const spanError = campo.querySelector(".mensaje-error");

  if (mensaje) {
    campo.classList.add("invalido");
    campo.classList.remove("valido");
    if (spanError) spanError.textContent = mensaje;
    return false;
  }

  campo.classList.remove("invalido");
  campo.classList.add("valido");
  if (spanError) spanError.textContent = "";
  return true;
}

/* ---------- Validadores individuales reutilizables ---------- */

function validarRequerido(inputEl, etiqueta = "Este campo") {
  const valor = inputEl.value.trim();
  if (valor === "") {
    return marcarCampo(inputEl, `${etiqueta} es obligatorio.`);
  }
  return marcarCampo(inputEl, "");
}

function validarLargoMaximo(inputEl, maximo, etiqueta = "Este campo") {
  const valor = inputEl.value.trim();
  if (valor.length > maximo) {
    return marcarCampo(inputEl, `${etiqueta} no puede superar ${maximo} caracteres.`);
  }
  return marcarCampo(inputEl, "");
}

function validarCorreo(inputEl, opcional = false) {
  const valor = inputEl.value.trim();
  if (valor === "") {
    if (opcional) return marcarCampo(inputEl, "");
    return marcarCampo(inputEl, "El correo es obligatorio.");
  }
  if (valor.length > 100) {
    return marcarCampo(inputEl, "El correo no puede superar 100 caracteres.");
  }
  if (!REGEX_CORREO_PERMITIDO.test(valor)) {
    return marcarCampo(
      inputEl,
      "Solo se aceptan correos @duoc.cl, @profesor.duoc.cl o @gmail.com."
    );
  }
  return marcarCampo(inputEl, "");
}

function validarContrasena(inputEl) {
  const valor = inputEl.value;
  if (valor === "") {
    return marcarCampo(inputEl, "La contraseña es obligatoria.");
  }
  if (valor.length < 4 || valor.length > 10) {
    return marcarCampo(inputEl, "La contraseña debe tener entre 4 y 10 caracteres.");
  }
  return marcarCampo(inputEl, "");
}

function validarConfirmacion(inputConfirmar, inputOriginal) {
  if (inputConfirmar.value !== inputOriginal.value) {
    return marcarCampo(inputConfirmar, "Las contraseñas no coinciden.");
  }
  return marcarCampo(inputConfirmar, "");
}

/** Valida el dígito verificador de un RUN chileno sin puntos ni guion. */
function validarRun(inputEl) {
  const valor = inputEl.value.trim().toUpperCase();

  if (valor === "") {
    return marcarCampo(inputEl, "El RUN es obligatorio.");
  }
  if (valor.length < 7 || valor.length > 9) {
    return marcarCampo(inputEl, "El RUN debe tener entre 7 y 9 caracteres, sin puntos ni guion.");
  }
  if (!/^\d+[0-9K]$/.test(valor)) {
    return marcarCampo(inputEl, "Formato de RUN inválido. Ejemplo: 19011022K.");
  }

  const cuerpo = valor.slice(0, -1);
  const dv = valor.slice(-1);
  let suma = 0;
  let multiplicador = 2;

  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += parseInt(cuerpo[i], 10) * multiplicador;
    multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
  }

  const resto = 11 - (suma % 11);
  const dvEsperado = resto === 11 ? "0" : resto === 10 ? "K" : String(resto);

  if (dv !== dvEsperado) {
    return marcarCampo(inputEl, "El RUN ingresado no es válido (dígito verificador incorrecto).");
  }

  return marcarCampo(inputEl, "");
}

function validarNumeroRango(inputEl, minimo, maximo, opcional = false) {
  const valor = inputEl.value.trim();
  if (valor === "") {
    if (opcional) return marcarCampo(inputEl, "");
    return marcarCampo(inputEl, "Este campo es obligatorio.");
  }
  const numero = Number(valor);
  if (Number.isNaN(numero)) {
    return marcarCampo(inputEl, "Debe ingresar un valor numérico.");
  }
  if (minimo !== null && numero < minimo) {
    return marcarCampo(inputEl, `El valor mínimo permitido es ${minimo}.`);
  }
  if (maximo !== null && numero > maximo) {
    return marcarCampo(inputEl, `El valor máximo permitido es ${maximo}.`);
  }
  return marcarCampo(inputEl, "");
}

function validarSeleccion(selectEl, etiqueta = "Debe seleccionar una opción") {
  if (selectEl.value.trim() === "") {
    return marcarCampo(selectEl, `${etiqueta}.`);
  }
  return marcarCampo(selectEl, "");
}

/* ---------- Formulario: Inicio de sesión (login.html) ---------- */
function inicializarValidacionLogin() {
  const form = document.getElementById("form-login");
  if (!form) return;

  const correo = document.getElementById("correo");
  const contrasena = document.getElementById("contrasena");

  correo.addEventListener("blur", () => validarCorreo(correo));
  contrasena.addEventListener("blur", () => validarContrasena(contrasena));

  form.addEventListener("submit", (evento) => {
    evento.preventDefault();
    const okCorreo = validarCorreo(correo);
    const okContrasena = validarContrasena(contrasena);

    if (okCorreo && okContrasena) {
      document.getElementById("mensaje-resultado").style.display = "block";
      form.reset();
      document
        .querySelectorAll(".campo")
        .forEach((c) => c.classList.remove("valido", "invalido"));
    }
  });
}

/* ---------- Formulario: Registro de usuario (registro.html) ---------- */
function inicializarValidacionRegistro() {
  const form = document.getElementById("form-registro");
  if (!form) return;

  const run = document.getElementById("run");
  const nombre = document.getElementById("nombre");
  const apellidos = document.getElementById("apellidos");
  const correo = document.getElementById("correo");
  const contrasena = document.getElementById("contrasena");
  const confirmar = document.getElementById("confirmar-contrasena");
  const direccion = document.getElementById("direccion");
  const region = document.getElementById("region");
  const comuna = document.getElementById("comuna");

  run.addEventListener("blur", () => validarRun(run));
  nombre.addEventListener("blur", () => {
    validarRequerido(nombre, "El nombre") && validarLargoMaximo(nombre, 50, "El nombre");
  });
  apellidos.addEventListener("blur", () => {
    validarRequerido(apellidos, "Los apellidos") &&
      validarLargoMaximo(apellidos, 100, "Los apellidos");
  });
  correo.addEventListener("blur", () => validarCorreo(correo));
  contrasena.addEventListener("blur", () => validarContrasena(contrasena));
  confirmar.addEventListener("blur", () => validarConfirmacion(confirmar, contrasena));
  direccion.addEventListener("blur", () => {
    validarRequerido(direccion, "La dirección") &&
      validarLargoMaximo(direccion, 300, "La dirección");
  });
  region.addEventListener("change", () => validarSeleccion(region, "Debe seleccionar una región"));
  comuna.addEventListener("change", () => validarSeleccion(comuna, "Debe seleccionar una comuna"));

  form.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const resultados = [
      validarRun(run),
      validarRequerido(nombre, "El nombre") && validarLargoMaximo(nombre, 50, "El nombre"),
      validarRequerido(apellidos, "Los apellidos") &&
        validarLargoMaximo(apellidos, 100, "Los apellidos"),
      validarCorreo(correo),
      validarContrasena(contrasena),
      validarConfirmacion(confirmar, contrasena),
      validarSeleccion(region, "Debe seleccionar una región"),
      validarSeleccion(comuna, "Debe seleccionar una comuna"),
      validarRequerido(direccion, "La dirección") &&
        validarLargoMaximo(direccion, 300, "La dirección"),
    ];

    if (resultados.every(Boolean)) {
      document.getElementById("mensaje-resultado").style.display = "block";
      form.reset();
      document
        .querySelectorAll(".campo")
        .forEach((c) => c.classList.remove("valido", "invalido"));
    }
  });
}

/* ---------- Formulario: Contacto (contacto.html) ---------- */
function inicializarValidacionContacto() {
  const form = document.getElementById("form-contacto");
  if (!form) return;

  const nombre = document.getElementById("nombre");
  const correo = document.getElementById("correo");
  const comentario = document.getElementById("comentario");

  nombre.addEventListener("blur", () => {
    validarRequerido(nombre, "El nombre") && validarLargoMaximo(nombre, 100, "El nombre");
  });
  correo.addEventListener("blur", () => validarCorreo(correo));
  comentario.addEventListener("blur", () => {
    validarRequerido(comentario, "El comentario") &&
      validarLargoMaximo(comentario, 500, "El comentario");
  });

  form.addEventListener("submit", (evento) => {
    evento.preventDefault();
    const resultados = [
      validarRequerido(nombre, "El nombre") && validarLargoMaximo(nombre, 100, "El nombre"),
      validarCorreo(correo),
      validarRequerido(comentario, "El comentario") &&
        validarLargoMaximo(comentario, 500, "El comentario"),
    ];

    if (resultados.every(Boolean)) {
      document.getElementById("mensaje-resultado").style.display = "block";
      form.reset();
      document
        .querySelectorAll(".campo")
        .forEach((c) => c.classList.remove("valido", "invalido"));
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  inicializarValidacionLogin();
  inicializarValidacionRegistro();
  inicializarValidacionContacto();
});
