/* =========================================================
   Veterinaria San Marcos - Script principal
   Menú móvil, año del footer, newsletter
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {
  // Menú hamburguesa
  const botonMenu = document.querySelector(".nav-toggle");
  const nav = document.querySelector("nav.main-nav");
  if (botonMenu && nav) {
    botonMenu.addEventListener("click", () => {
      nav.classList.toggle("open");
      const expandido = nav.classList.contains("open");
      botonMenu.setAttribute("aria-expanded", expandido);
    });
  }

  // Año dinámico en el footer
  document.querySelectorAll(".anio-actual").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });

  // Formulario de newsletter (footer) - simulación
  const formNewsletter = document.querySelector(".newsletter-form");
  if (formNewsletter) {
    formNewsletter.addEventListener("submit", (evento) => {
      evento.preventDefault();
      const correo = formNewsletter.querySelector("input[type='email']");
      if (correo && correo.value.trim() !== "") {
        alert(`Gracias por suscribirte, te escribiremos a ${correo.value}`);
        formNewsletter.reset();
      }
    });
  }
});
