/* =========================================================
   Veterinaria San Marcos - Panel administrador
   Mantenedores simulados con localStorage (sin backend,
   ya que esta entrega corresponde solo al frontend).
   ========================================================= */

const CLAVE_ADMIN_USUARIOS = "vsm_admin_usuarios";
const CLAVE_ADMIN_PRODUCTOS = "vsm_admin_productos";

const USUARIOS_DEMO = [
  {
    run: "191102201",
    nombre: "Camila",
    apellidos: "Reyes Soto",
    correo: "camila.reyes@duoc.cl",
    tipo: "Administrador",
    region: "Región Metropolitana de Santiago",
    comuna: "Santiago",
    direccion: "Av. Siempre Viva 123",
  },
  {
    run: "180456782",
    nombre: "Pedro",
    apellidos: "Muñoz Díaz",
    correo: "pedro.munoz@gmail.com",
    tipo: "Vendedor",
    region: "Región del Libertador Gral. B. O'Higgins",
    comuna: "Rancagua",
    direccion: "Calle Los Aromos 456",
  },
  {
    run: "205678901",
    nombre: "Javiera",
    apellidos: "López Peña",
    correo: "javiera.lopez@profesor.duoc.cl",
    tipo: "Cliente",
    region: "Región de la Araucanía",
    comuna: "Temuco",
    direccion: "Pasaje Las Rosas 789",
  },
];

function leerAdminUsuarios() {
  const datos = localStorage.getItem(CLAVE_ADMIN_USUARIOS);
  if (datos) return JSON.parse(datos);
  guardarAdminUsuarios(USUARIOS_DEMO);
  return USUARIOS_DEMO;
}

function guardarAdminUsuarios(usuarios) {
  localStorage.setItem(CLAVE_ADMIN_USUARIOS, JSON.stringify(usuarios));
}

function leerAdminProductos() {
  const datos = localStorage.getItem(CLAVE_ADMIN_PRODUCTOS);
  if (datos) return JSON.parse(datos);
  guardarAdminProductos(CATALOGO_PRODUCTOS);
  return CATALOGO_PRODUCTOS;
}

function guardarAdminProductos(productos) {
  localStorage.setItem(CLAVE_ADMIN_PRODUCTOS, JSON.stringify(productos));
}

/* ---------- Dashboard (admin/index.html) ---------- */
function renderizarDashboardAdmin() {
  const contUsuarios = document.getElementById("resumen-usuarios");
  const contProductos = document.getElementById("resumen-productos");
  const contStockCritico = document.getElementById("resumen-stock-critico");
  if (!contUsuarios) return;

  const usuarios = leerAdminUsuarios();
  const productos = leerAdminProductos();
  const stockCritico = productos.filter(
    (p) => p.stockCritico > 0 && p.stock <= p.stockCritico
  );

  contUsuarios.textContent = usuarios.length;
  contProductos.textContent = productos.length;
  contStockCritico.textContent = stockCritico.length;
}

/* ---------- Listado de usuarios (admin/usuarios.html) ---------- */
function renderizarListadoUsuarios() {
  const tbody = document.getElementById("cuerpo-tabla-usuarios");
  if (!tbody) return;

  const usuarios = leerAdminUsuarios();

  tbody.innerHTML = usuarios
    .map(
      (u, indice) => `
      <tr>
        <td>${u.run}</td>
        <td>${u.nombre} ${u.apellidos}</td>
        <td>${u.correo}</td>
        <td><span class="badge badge-ok">${u.tipo}</span></td>
        <td>${u.comuna}</td>
        <td class="acciones-tabla">
          <a href="usuario-nuevo.html?index=${indice}">Editar</a>
          <button type="button" onclick="eliminarUsuarioAdmin(${indice})">Eliminar</button>
        </td>
      </tr>`
    )
    .join("");
}

function eliminarUsuarioAdmin(indice) {
  const usuarios = leerAdminUsuarios();
  if (!confirm(`¿Eliminar al usuario ${usuarios[indice].nombre}?`)) return;
  usuarios.splice(indice, 1);
  guardarAdminUsuarios(usuarios);
  renderizarListadoUsuarios();
}

function filtrarUsuariosAdmin(texto) {
  const filas = document.querySelectorAll("#cuerpo-tabla-usuarios tr");
  filas.forEach((fila) => {
    fila.style.display = fila.textContent.toLowerCase().includes(texto.toLowerCase())
      ? ""
      : "none";
  });
}

/* ---------- Formulario nuevo/editar usuario ---------- */
function inicializarFormularioUsuarioAdmin() {
  const form = document.getElementById("form-usuario-admin");
  if (!form) return;

  const params = new URLSearchParams(window.location.search);
  const indice = params.get("index");
  const usuarios = leerAdminUsuarios();

  poblarSelectRegiones("region", "comuna");

  if (indice !== null && usuarios[indice]) {
    const u = usuarios[indice];
    document.getElementById("titulo-formulario-usuario").textContent = "Editar usuario";
    document.getElementById("run").value = u.run;
    document.getElementById("run").disabled = true;
    document.getElementById("nombre").value = u.nombre;
    document.getElementById("apellidos").value = u.apellidos;
    document.getElementById("correo").value = u.correo;
    document.getElementById("tipo-usuario").value = u.tipo;
    document.getElementById("direccion").value = u.direccion;
    setTimeout(() => {
      document.getElementById("region").value = u.region;
      document.getElementById("region").dispatchEvent(new Event("change"));
      setTimeout(() => (document.getElementById("comuna").value = u.comuna), 50);
    }, 50);
  }

  form.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const run = document.getElementById("run");
    const nombre = document.getElementById("nombre");
    const apellidos = document.getElementById("apellidos");
    const correo = document.getElementById("correo");
    const tipoUsuario = document.getElementById("tipo-usuario");
    const region = document.getElementById("region");
    const comuna = document.getElementById("comuna");
    const direccion = document.getElementById("direccion");

    const resultados = [
      run.disabled ? true : validarRun(run),
      validarRequerido(nombre, "El nombre") && validarLargoMaximo(nombre, 50, "El nombre"),
      validarRequerido(apellidos, "Los apellidos") &&
        validarLargoMaximo(apellidos, 100, "Los apellidos"),
      validarCorreo(correo),
      validarSeleccion(tipoUsuario, "Debe seleccionar un tipo de usuario"),
      validarSeleccion(region, "Debe seleccionar una región"),
      validarSeleccion(comuna, "Debe seleccionar una comuna"),
      validarRequerido(direccion, "La dirección") &&
        validarLargoMaximo(direccion, 300, "La dirección"),
    ];

    if (!resultados.every(Boolean)) return;

    const nuevoUsuario = {
      run: run.value.trim().toUpperCase(),
      nombre: nombre.value.trim(),
      apellidos: apellidos.value.trim(),
      correo: correo.value.trim(),
      tipo: tipoUsuario.value,
      region: region.value,
      comuna: comuna.value,
      direccion: direccion.value.trim(),
    };

    const listaUsuarios = leerAdminUsuarios();
    if (indice !== null && listaUsuarios[indice]) {
      listaUsuarios[indice] = nuevoUsuario;
    } else {
      listaUsuarios.push(nuevoUsuario);
    }
    guardarAdminUsuarios(listaUsuarios);
    window.location.href = "usuarios.html";
  });
}

/* ---------- Listado de productos (admin/productos.html) ---------- */
function renderizarListadoProductosAdmin() {
  const tbody = document.getElementById("cuerpo-tabla-productos");
  if (!tbody) return;

  const productos = leerAdminProductos();

  tbody.innerHTML = productos
    .map((p, indice) => {
      const critico = p.stockCritico > 0 && p.stock <= p.stockCritico;
      return `
      <tr>
        <td>${p.id}</td>
        <td>${p.nombre}</td>
        <td>${p.categoria}</td>
        <td>${formatearCLP(p.precio)}</td>
        <td>
          ${p.stock}
          ${critico ? '<span class="badge badge-alerta">Stock crítico</span>' : ""}
        </td>
        <td class="acciones-tabla">
          <a href="producto-nuevo.html?index=${indice}">Editar</a>
          <button type="button" onclick="eliminarProductoAdmin(${indice})">Eliminar</button>
        </td>
      </tr>`;
    })
    .join("");
}

function eliminarProductoAdmin(indice) {
  const productos = leerAdminProductos();
  if (!confirm(`¿Eliminar el producto ${productos[indice].nombre}?`)) return;
  productos.splice(indice, 1);
  guardarAdminProductos(productos);
  renderizarListadoProductosAdmin();
}

function filtrarProductosAdmin(texto) {
  const filas = document.querySelectorAll("#cuerpo-tabla-productos tr");
  filas.forEach((fila) => {
    fila.style.display = fila.textContent.toLowerCase().includes(texto.toLowerCase())
      ? ""
      : "none";
  });
}

/* ---------- Formulario nuevo/editar producto ---------- */
function inicializarFormularioProductoAdmin() {
  const form = document.getElementById("form-producto-admin");
  if (!form) return;

  const params = new URLSearchParams(window.location.search);
  const indice = params.get("index");
  const productos = leerAdminProductos();

  if (indice !== null && productos[indice]) {
    const p = productos[indice];
    document.getElementById("titulo-formulario-producto").textContent = "Editar producto";
    document.getElementById("codigo").value = p.id;
    document.getElementById("codigo").disabled = true;
    document.getElementById("prod-nombre").value = p.nombre;
    document.getElementById("descripcion").value = p.descripcion;
    document.getElementById("precio").value = p.precio;
    document.getElementById("stock").value = p.stock;
    document.getElementById("stock-critico").value = p.stockCritico;
    document.getElementById("categoria").value = p.categoria;
  }

  form.addEventListener("submit", (evento) => {
    evento.preventDefault();

    const codigo = document.getElementById("codigo");
    const nombre = document.getElementById("prod-nombre");
    const descripcion = document.getElementById("descripcion");
    const precio = document.getElementById("precio");
    const stock = document.getElementById("stock");
    const stockCritico = document.getElementById("stock-critico");
    const categoria = document.getElementById("categoria");

    const resultados = [
      codigo.disabled
        ? true
        : validarRequerido(codigo, "El código") &&
          validarLargoMaximo(codigo, 20, "El código") &&
          (codigo.value.trim().length >= 3 ||
            marcarCampo(codigo, "El código debe tener al menos 3 caracteres.")),
      validarRequerido(nombre, "El nombre") && validarLargoMaximo(nombre, 100, "El nombre"),
      validarLargoMaximo(descripcion, 500, "La descripción"),
      validarNumeroRango(precio, 0, null),
      validarNumeroRango(stock, 0, null),
      validarNumeroRango(stockCritico, 0, null, true),
      validarSeleccion(categoria, "Debe seleccionar una categoría"),
    ];

    if (!resultados.every(Boolean)) return;

    const nuevoProducto = {
      id: codigo.value.trim().toUpperCase(),
      nombre: nombre.value.trim(),
      categoria: categoria.value,
      precio: Number(precio.value),
      stock: parseInt(stock.value, 10),
      stockCritico: stockCritico.value ? parseInt(stockCritico.value, 10) : 0,
      descripcion: descripcion.value.trim(),
    };

    const listaProductos = leerAdminProductos();
    if (indice !== null && listaProductos[indice]) {
      listaProductos[indice] = nuevoProducto;
    } else {
      listaProductos.push(nuevoProducto);
    }
    guardarAdminProductos(listaProductos);
    window.location.href = "productos.html";
  });
}

document.addEventListener("DOMContentLoaded", () => {
  renderizarDashboardAdmin();
  renderizarListadoUsuarios();
  renderizarListadoProductosAdmin();
  inicializarFormularioUsuarioAdmin();
  inicializarFormularioProductoAdmin();
});
