/* =========================================================
   Veterinaria San Marcos - Regiones y comunas (dataset reducido)
   Complementario para los selects dependientes de los
   formularios de registro y administración de usuarios.
   ========================================================= */

const REGIONES_COMUNAS = {
  "Región Metropolitana de Santiago": [
    "Santiago",
    "Providencia",
    "Ñuñoa",
    "Maipú",
    "Puente Alto",
  ],
  "Región del Libertador Gral. B. O'Higgins": [
    "Rancagua",
    "Machalí",
    "San Fernando",
    "Rengo",
  ],
  "Región de la Araucanía": ["Temuco", "Villarrica", "Angol", "Pucón"],
  "Región de Ñuble": ["Chillán", "San Carlos", "Bulnes"],
  "Región del Biobío": ["Concepción", "Talcahuano", "Los Ángeles"],
};

function poblarSelectRegiones(selectRegionId, selectComunaId) {
  const selectRegion = document.getElementById(selectRegionId);
  const selectComuna = document.getElementById(selectComunaId);
  if (!selectRegion || !selectComuna) return;

  selectRegion.innerHTML =
    `<option value="">-- Seleccione la región --</option>` +
    Object.keys(REGIONES_COMUNAS)
      .map((region) => `<option value="${region}">${region}</option>`)
      .join("");

  selectComuna.innerHTML = `<option value="">-- Seleccione la comuna --</option>`;

  selectRegion.addEventListener("change", () => {
    const comunas = REGIONES_COMUNAS[selectRegion.value] || [];
    selectComuna.innerHTML =
      `<option value="">-- Seleccione la comuna --</option>` +
      comunas.map((comuna) => `<option value="${comuna}">${comuna}</option>`).join("");
  });
}
