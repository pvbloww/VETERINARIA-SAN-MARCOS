/* =========================================================
   Veterinaria San Marcos - Carrito de compras
   Persistencia en localStorage
   ========================================================= */

const CLAVE_CARRITO = "vsm_carrito";

function leerCarrito() {
  try {
    const datos = localStorage.getItem(CLAVE_CARRITO);
    return datos ? JSON.parse(datos) : [];
  } catch (error) {
    console.error("No se pudo leer el carrito guardado:", error);
    return [];
  }
}

function guardarCarrito(carrito) {
  localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito));
  actualizarContadorCarrito();
}

function agregarAlCarrito(idProducto, cantidad = 1) {
  const carrito = leerCarrito();
  const item = carrito.find((i) => i.id === idProducto);

  if (item) {
    item.cantidad += cantidad;
  } else {
    carrito.push({ id: idProducto, cantidad });
  }

  guardarCarrito(carrito);
}

function actualizarCantidadCarrito(idProducto, nuevaCantidad) {
  let carrito = leerCarrito();
  if (nuevaCantidad <= 0) {
    carrito = carrito.filter((i) => i.id !== idProducto);
  } else {
    const item = carrito.find((i) => i.id === idProducto);
    if (item) item.cantidad = nuevaCantidad;
  }
  guardarCarrito(carrito);
  renderizarCarrito();
}

function eliminarDelCarrito(idProducto) {
  const carrito = leerCarrito().filter((i) => i.id !== idProducto);
  guardarCarrito(carrito);
  renderizarCarrito();
}

function totalUnidadesCarrito() {
  return leerCarrito().reduce((total, i) => total + i.cantidad, 0);
}

function actualizarContadorCarrito() {
  document.querySelectorAll(".contador-carrito").forEach((el) => {
    el.textContent = totalUnidadesCarrito();
  });
}

/* ---- Renderizado de la página carrito.html ---- */
function renderizarCarrito() {
  const contenedor = document.getElementById("cuerpo-carrito");
  if (!contenedor) return;

  const carrito = leerCarrito();
  const vacio = document.getElementById("carrito-vacio");
  const tabla = document.getElementById("tabla-carrito-wrapper");

  if (carrito.length === 0) {
    if (vacio) vacio.style.display = "block";
    if (tabla) tabla.style.display = "none";
    return;
  }

  if (vacio) vacio.style.display = "none";
  if (tabla) tabla.style.display = "block";

  let total = 0;

  contenedor.innerHTML = carrito
    .map((item) => {
      const producto = obtenerProductoPorId(item.id);
      if (!producto) return "";
      const subtotal = producto.precio * item.cantidad;
      total += subtotal;
      return `
        <tr>
          <td>
            <div class="fila-producto-carrito">
              <div class="placeholder-img">${producto.nombre}</div>
              <div>
                <strong>${producto.nombre}</strong><br/>
                <small>${producto.categoria}</small>
              </div>
            </div>
          </td>
          <td>${formatearCLP(producto.precio)}</td>
          <td>
            <div class="controles-cantidad">
              <button type="button" aria-label="Disminuir cantidad" onclick="actualizarCantidadCarrito('${producto.id}', ${item.cantidad - 1})">-</button>
              <span>${item.cantidad}</span>
              <button type="button" aria-label="Aumentar cantidad" onclick="actualizarCantidadCarrito('${producto.id}', ${item.cantidad + 1})">+</button>
            </div>
          </td>
          <td>${formatearCLP(subtotal)}</td>
          <td>
            <button type="button" class="btn btn-secundario" onclick="eliminarDelCarrito('${producto.id}')">Quitar</button>
          </td>
        </tr>`;
    })
    .join("");

  const totalEl = document.getElementById("total-carrito");
  if (totalEl) totalEl.textContent = formatearCLP(total);
}

function vaciarCarrito() {
  guardarCarrito([]);
  renderizarCarrito();
}

function procesarPago(evento) {
  evento.preventDefault();
  const carrito = leerCarrito();
  if (carrito.length === 0) {
    alert("Tu carrito está vacío. Añade productos antes de continuar.");
    return;
  }
  alert(
    "¡Gracias por tu compra! Este es un flujo de demostración para la evaluación parcial 1."
  );
  vaciarCarrito();
}

document.addEventListener("DOMContentLoaded", () => {
  actualizarContadorCarrito();
  renderizarCarrito();
});
